package app;

import circularList.CircularList;
import node.node;

public class App {

	public static <T> void main(String[] args) {
		
		CircularList<String> names = new CircularList<String>();
		names.addFirst("Andrik");
		names.addFirst("Yarely");
		names.addFirst("Luis");
		names.addFirst("Daniel");
		names.addFirst("Javier");
		names.addFirst("Fernando");
		names.pronter();
		
        System.out.println("--------------  Tamaño  --------------");
		System.out.println(names.size());
		
		node<T> nombre=(node<T>) names.getLast();
		System.out.println("--------------  Search --------------");
		nombre =(node<T>) names.Search("Luis");
		if(nombre!=null)
		{
			System.out.println(nombre.getValue());
		}
	
		System.out.println("--------------  Reindex  --------------");
		names.pronter();
		names.pronterIndex();
		
		System.out.println("--------------  IndexOf  --------------");
		nombre =(node<T>) names.indexof("Andrik");
		if(nombre!=null)
		{
			System.out.println(nombre.getValue()+" esta en la posicion: "+ nombre.getIndex());
		}
		
		System.out.println("--------------  GetLast  --------------");
		nombre =(node<T>) names.getLast();
		if(nombre!=null)
		{
			System.out.println(nombre.getValue());
		}
		
		System.out.println("--------------  RemoveAfter (Yarely) --------------");
		names.removeAfter("Yarely");
		names.pronter();
		
		System.out.println("--------------  RemoveBefore (Luis) --------------");
		names.removeBefore("Luis");
		names.pronter();
		
		System.out.println("--------------  IsEmpty  --------------");
		boolean resp=names.isEmpty();
		if(resp)
		{
			System.out.println("La lista esta vacia");
		}else
		{
			System.out.println("La lista no esta vacia");
		}
		
		System.out.println("--------------  Remplazar(Luis por Jesus)  --------------");
		names.remplazar("Luis", "Jesus");
        names.pronter();
        
        System.out.println("--------------  Remove Last  --------------");
		names.removelast();
        names.pronter();
        
        System.out.println("--------------  Get Frist  --------------");
		names.getfrist();
        
        System.out.println("--------------  Remove Frist  --------------");
		names.removefirst();
		names.pronter();
       
        System.out.println("--------------  Clear --------------");
        names.clear();
		boolean resp1=names.isEmpty();
		if(resp1)
		{
			System.out.println("La lista esta vacia");
		}else
		{
			System.out.println("La lista no esta vacia");
		}
			
	}
}