package circularList;
import node.node;

public class CircularList<T> {
	private node<T> sentinel=null;
	private node<T> actual=null;
	private int size = 0;
	
	public CircularList() {
		sentinel = new node<T>();
		actual = new node<T>();
		sentinel.setIndex(-1);
		actual.setIndex(-1);
	}
	public CircularList(T value){
		this();
		sentinel.setNext(new node<T>(value));
		actual = sentinel.getNext();
		sentinel.getNext().setNext(actual);
	}
	public boolean isEmpty(){
		return (sentinel.getNext() == null)?true:false;
	}
	
	public node<T> getLast(){
		node<T> tmp = sentinel.getNext();
		if(!isEmpty()){
			while(!sentinel.getNext().equals(tmp.getNext()))
				tmp = tmp.getNext();
			return tmp;
		}//end if
		return null;
	}
	public void pronter(){
		node<T> tmp = sentinel.getNext();
		if(!isEmpty())
		while(!tmp.getNext().equals(sentinel.getNext())){
			System.out.println(tmp.getValue());
			tmp = tmp.getNext();
		}
		System.out.println(tmp.getValue());
	}
	public void addFirst(T value){
		node<T> nuevo = new node<T>(value),last = getLast();
		//node<T> last = getLast();
		if(isEmpty()){
			sentinel.setNext(nuevo);
			nuevo.setNext(nuevo);
		}else{
			nuevo.setNext(sentinel.getNext());
			sentinel.setNext(nuevo);
			last.setNext(nuevo);
		}
		size++;
	}
	public node<T> Search(T value){
		return (!isEmpty())?Search(value,sentinel.getNext()):null;
	}
	private node<T> Search(T value,node<T> list){
		if(list.getNext().getValue().equals(value)){
			return list.getNext();
		}
		if(list.getNext().equals(sentinel.getNext())){
			return null;
		}
		
		return Search(value,list.getNext());
	}
	public node<T> SearchBefore(T value)
	{
		return SearchBefore(value, sentinel.getNext());
	}
	private node<T> SearchBefore(T value,node<T> list){
		if(list.getNext().getValue().equals(value)){
			return list;
		}
		else if(list.getNext().equals(sentinel.getNext())){
			return null;
		}
		return SearchBefore(value,list.getNext());
	}
	public boolean remove(T value){
		if(!isEmpty()){
			node<T> found = Search(value);
			if(found != null){
				node<T> tmp = SearchBefore(value,sentinel.getNext());
				if(tmp.equals(tmp.getNext()))
					sentinel.setNext(null);
				else if(sentinel.getNext().equals(found)){
					sentinel.setNext(found.getNext());
					tmp.setNext(found.getNext());
				}else{
					tmp.setNext(found.getNext());
				}
			}
		}
		return true;
	}
	private void reindex() {
		int aux=1;
		node<T> tmp = sentinel.getNext();
		if(!isEmpty())
		{
			do{
				tmp.setIndex(aux);
				tmp = tmp.getNext();
				aux++;
			}while (!tmp.getNext().equals(sentinel.getNext()));
			tmp.setIndex(aux);
			System.gc();
		}
	}
	public node<T> indexof(T value)
	{
		reindex();
		return indexof(value,sentinel.getNext());
	}
	public node<T> indexof(T value, node<T> lista)
	{
		if(lista.getValue().equals(value)) 
		{
			return lista;
		}else if (lista.getNext()==sentinel.getNext())
			{
			return null;
			}
		return indexof(value, lista.getNext());
	}
	public void pronterIndex(){
		reindex();
		node<T> tmp = sentinel.getNext();
		if(!isEmpty())
		while(!tmp.getNext().equals(sentinel.getNext())){
			System.out.println(tmp.getIndex());
			tmp = tmp.getNext();
		}
		System.out.println(tmp.getIndex());
	}
	public void removeAfter(T value)
	{
		if(!isEmpty())
		{
			node<T> tmp=Search(value);
			if (tmp!=null)
			{
				if(tmp.getNext().equals(sentinel.getNext()))
				{
					tmp.setNext(tmp.getNext().getNext());
					sentinel.setNext(sentinel.getNext().getNext());
				}else
				{
					tmp.setNext(tmp.getNext().getNext());
				}
			}
		}
	}
	public boolean removelast(){
		node<T> last = getLast();
		if(!isEmpty()){
			node<T> found = Search(last.getValue());
			if(found != null){
				node<T> tmp = SearchBefore(last.getValue(), sentinel.getNext());
				if(tmp.equals(tmp.getNext()))
					sentinel.setNext(null);
				else if(sentinel.getNext().equals(found)){
					 sentinel.setNext(found.getNext());
					 tmp.setNext(found.getNext());
				 }else{
					 tmp.setNext(found.getNext());
				 }
			}
		}
		return true;
	}
	public T removeBefore(T value){
		 
		 return removeBefore(value,sentinel); 
		 
	 }
	 private T removeBefore(T value, node<T> lista){
		 node<T> tmp = lista;			
		 lista=lista.getNext();
		 if(lista.getNext().getValue().equals(value)){
			 tmp.setNext(tmp.getNext().getNext()); 
		 }else{
			 return removeBefore(value,lista); 
		 }
		 return value;
	 }
	 public void remplazar(T value, T remp)
	 {
		 Search(value).setValue(remp);
	 }
	 public void clear()
	 {
		 sentinel.setNext(null);
	     System.gc();
	 }
	public int size()
	{
		return size;
	}
	public void getfrist()
	{
		System.out.println(sentinel.getNext().getValue());
	}
	public void removefirst()
	{
		remove(sentinel.getNext().getValue());
	}
}
